$(document).ready(function(){
	$("#browser").treeview();
});