<div class="col-md-9" id="content-container">
<div class="panel panel-primary">
    
        <div class="panel-heading"><h3 class="panel-title">Content</h3></div>
        <div class="panel-body"> 
            
                <div class="row clearfix">
                <div class="col-md-12 column" id="post">
                HALAMAN TIDAK DITEMUKAN
                </div>
                </div>  
        
        </div>
    
    </div>
</div>