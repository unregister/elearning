	</div>
    <footer>
    	<div class="container">
        Copyright 2014 E-Learning
        </div>
    </footer>
</div>
</body>
</html>