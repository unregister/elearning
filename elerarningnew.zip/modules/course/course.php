<div class="col-md-9" id="content-container">
<div class="panel panel-primary">
    
        <div class="panel-heading"><h3 class="panel-title">Content</h3></div>
        <div class="panel-body"> 
            
                <div class="row clearfix">
                <div class="col-md-12 column" id="post">
                
                <p>
                	<a href="">
                    	<i class="glyphicon glyphicon-file"></i>
                    	<span class="course">Porta gravida at eget metus</span>
                    </a>
                </p>
                
                <p>
                	<a href="">
                    	<i class="glyphicon glyphicon-file"></i>
                    	<span class="course">Porta gravida at eget metus</span>
                    </a>
                </p>
                
                <p>
                	<a href="">
                    	<i class="glyphicon glyphicon-file"></i>
                    	<span class="course">Porta gravida at eget metus</span>
                    </a>
                </p>
                
                <p>
                	<a href="">
                    	<i class="glyphicon glyphicon-file"></i>
                    	<span class="course">Porta gravida at eget metus</span>
                    </a>
                </p>
                
                <p>
                	<a href="">
                    	<i class="glyphicon glyphicon-file"></i>
                    	<span class="course">Porta gravida at eget metus</span>
                    </a>
                </p>
                
                <p>
                	<a href="">
                    	<i class="glyphicon glyphicon-file"></i>
                    	<span class="course">Porta gravida at eget metus</span>
                    </a>
                </p>
                
                <p>
                	<a href="">
                    	<i class="glyphicon glyphicon-file"></i>
                    	<span class="course">Porta gravida at eget metus</span>
                    </a>
                </p>
                
                </div>
                </div>  
        
        </div>
    
    </div>
</div>