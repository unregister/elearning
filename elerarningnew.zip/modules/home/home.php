<div class="col-md-9" id="content-container">
<div class="panel panel-primary">
    
        <div class="panel-heading"><h3 class="panel-title">Content</h3></div>
        <div class="panel-body"> 
            
                <div class="row clearfix">
                
                    <div class="col-md-12 column" id="post">
                    	<div id="post-content">
                            <h2><a href="">Porta gravida at eget metus</a></h2>
                            <p>
                                Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
                            </p>
                            <p>
                                <a class="btn" href="#">View details »</a>
                            </p>
                        </div>
                    </div>
                    
                    <div class="col-md-12 column" id="post">
                       <div id="post-content">
                            <h2><a href="">Donec id elit non mi porta gravida at eget metus</a></h2>
                            <p>
                                Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
                            </p>
                            <p>
                                <a class="btn" href="#">View details »</a>
                            </p>
                        </div>
                    </div>
                    
                    <div class="col-md-12 column" id="post">
                    	<div id="post-content">
                            <h2><a href="">Fermentum massa justo sit amet risus</a></h2>
                            <p>
                                Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
                            </p>
                            <p>
                                <a class="btn" href="#">View details »</a>
                            </p>
                        </div>
                    </div>
                    
                    <div class="col-md-12 column" id="post">
                       <div id="post-content">
                            <h2><a href="">Fusce dapibus, tellus ac cursus commodo</a></h2>
                            <p>
                                Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
                            </p>
                            <p>
                                <a class="btn" href="#">View details »</a>
                            </p>
                        </div>
                    </div>
                    
                </div>  
        
        </div>
    
    </div>
</div>